  let heightLevel = 50; // نسبة ارتفاع أولي
 function movePlatform(direction) {
 const fill = document.getElementById("platformFill");
  const msg = document.getElementById("message");
  if (direction === 'up') {
    if (heightLevel >= 100) {
      msg.textContent = " تم الوصول لأعلى إرتفاع.";
      return;
    }
    heightLevel += 10;
  } else if (direction === 'down') {
    if (heightLevel <= 0) {
      msg.textContent = " تم الوصول لأدنى إرتفاع.";
      return;
    }
    heightLevel -= 10;
  }
  fill.style.height = heightLevel + "%";
  if (heightLevel === 100) {
    msg.textContent = " المنصة في أقصى إرتفاع.";
  } else if (heightLevel === 0) {
    msg.textContent = " المنصة في أدنى نقطة .";
  } else {
    msg.textContent = ` الأرتفاع الحالي : ${heightLevel}٪`;
  }}
 
